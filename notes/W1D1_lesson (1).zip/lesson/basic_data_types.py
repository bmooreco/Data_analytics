#Basic Data Types: string, integer, float, boolean

# my_name = 'Juliana'
# print(type(my_name))


# some_variable = 35
# print(type(some_variable))

# some_variable = 5.5
# print(type(some_variable))

# my_bool = True
# print(type(my_bool))

# #STRINGS
# greetings = 'shabat shalom\t'
# print('index of space:', greetings.index('s'))


# #indexing a string
# print(greetings[3])

# #slicing a string
# print(greetings[2:5])
# print(greetings[2:])
# #-1 is the last index 

# #Strings most used methods
# print(len(greetings))
# print(greetings[2:len(greetings)])

# #string methods

# print(greetings.capitalize())
# print(greetings.title())

# greetings = greetings.replace('$', '').title()
# print(greetings)
# # print(greetings_new)

# student = "  Harry Potter $"
# student = student.strip('')
# student.replace('r', '')
# print(student.replace('r', 'l') + 'hello')


#NUMBERS: integer, float, comple numbers, boolean

# int_num = 5 #int: whole numbers
# float_num = 7.5

# #OPERATIONS

# print(type(float_num))
# print(-6 + 3)
# print(5-(-8))

# print(10*2)
# print(5**2)
# # print(greetings *10)
# #\n \t

# print(round(5/3,4))
# print(11//2) #floor division
# print(11%2) #modulos operator

# if 12%3 == 0:
#     print('yes!')

# my_age = 34
# print(my_age + 123879)
# print(type(my_age))

# my_age = str(my_age)
# print(type(my_age))

# my_phone = '055226699'
# my_phone = int(my_phone)
# print(type(my_phone))

# # my_age = int(input('What is your age?'))
# # print(type(my_age))

# # if my_age < 18:
# #     print("you can't drink vodka")
# # else:
# #     print('Uhuu let\'s celebrate')

# #COMPARISON OPERATORS
# print(5 <= 7)
# print(5 < 5)
# print(5 > 3)
# print('3' == 3)

# #adding data types together

# f_name = 'Hermione'
# l_name = 'Granger'
# hermione_age = 15

# print("Hello, " + f_name + ' ' + l_name + 'your age is ' + str(hermione_age))

# #f string

# print(f'Hello, {f_name} {l_name}, welcome to Hogwarts! your age is {hermione_age}')

# BOOLEANS (TRUE = 1, FALSE = 0)
# print('python' is 'python')
# print('python' is not 'python')
# print('HTML' is not "CSS" and 'Python' is 'Javascript')

# if 'HTML' is not "CSS" and 'Python' is 'Javascript':
#     print('That\'s right!')


#NAMING VARIABLES
# #JS - Camel Case
# # myAge = 34 #JS way - NOT PYTHON
# # my_age = 34 (python way)

# #JS - let, const, var = keywords to define if the variable should be changed/overwrited

# #Python = Uppercase
# PASSWORD = '123456'

# my_age = 34
# my_age += 1
# print(my_age)

#exercise 3
# age = input("How old are you? ")
# print(f"You are {age} years old")

# print(age > 18)





