#FOR LOOP

#syntax

# students = ['Alex', 'Noah', 'Sara', 'Dima','Juliana']

# for each_student in students:
#     if each_student == 'Dima':
#         print(f'Doble Utra, {each_student}')
#     else:
#         print(f'Good morning, {each_student}')

# for i in range(len(students)):
#     print(f'Hello there {i}')

# for index, each_student in enumerate(students):
#     print(i, each_student)


# my_nums = [3,5,7,8,10]

# print(sum(my_nums))

# output = 0
# for i in range(len(my_nums)):
#    output += my_nums[i]
# print(output)


#WHILE LOOP

# i = 0
# while i < 10:
#     print(f'Hi {i}')
#     i += 1

# family = []
# keep_asking = True

# while keep_asking:
#     member = input('write the family member name. press "q" to finish')
#     if member == 'q':
#         keep_asking = False
#     else:
#         family.append(member)

# print(family)
